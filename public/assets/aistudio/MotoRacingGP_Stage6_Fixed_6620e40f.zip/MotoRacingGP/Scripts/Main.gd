extends Node3D

# MOTO RACING GP - Stage 6 (revisi engineering)
# Sirkuit S periodik (loop mulus), motor 1 kesatuan, kontrol sentuh multi-touch.
# Target: Godot 4.3+, GL Compatibility, Android landscape, 30 FPS.

enum State { RACING, PAUSED, FINISHED }

# --- Fisika / gameplay ---
const MAX_SPEED := 250.0
const ACCELERATION := 72.0
const BRAKE_POWER := 145.0
const DRAG := 22.0
const WORLD_SPEED := 0.12        # km/j -> unit dunia per detik
const TOTAL_LAPS := 3
const MAX_STEER_OFFSET := 7.0

# --- Sirkuit ---
# LAP_LENGTH harus kelipatan TRACK_PERIOD, SEGMENT_LENGTH, KERB_STEP, LINE_STEP
# dan BARRIER_STEP. Dengan begitu dunia identik setelah "teleport" satu lap
# (tidak ada lompatan posisi, arah, atau pola garis).
const TRACK_WIDTH := 18.0
const TRACK_PERIOD := 270.0
const TRACK_AMPLITUDE := 4.0
const TRACK_K := TAU / TRACK_PERIOD
const LAP_LENGTH := 540.0
const SEGMENT_LENGTH := 22.5
const KERB_STEP := 5.625
const LINE_STEP := 15.0
const BARRIER_STEP := 13.5
const VIEW_DISTANCE := 360.0
const BEHIND_DISTANCE := 45.0

# --- Motor ---
const WHEEL_RADIUS := 0.38
const WHEEL_Y := 0.40            # pusat roda: ban tepat menyentuh aspal (y = 0.02)

const AXIS_Y := 0
const AXIS_X := 1
const AXIS_Z := 2

# --- State ---
var state: State = State.RACING
var speed := 0.0
var player_x := 0.0              # target posisi lateral terhadap garis tengah
var lateral_x := 0.0             # posisi lateral yang sudah di-smooth
var player_yaw := 0.0
var lean_angle := 0.0
var wheel_spin := 0.0
var throttle := false
var braking := false
var steer_left := false
var steer_right := false
var camera_mode := 0             # 0 = belakang, 1 = helm
var race_time := 0.0
var lap_start_time := 0.0
var best_lap := -1.0
var timing_started := false
var score_f := 0.0
var score := 0
var lap := 1
var message_time := 0.0          # 0 = pesan menetap sampai diganti

# --- Node ---
var player_bike: Node3D
var player_lean: Node3D
var front_wheel: Node3D
var rear_wheel: Node3D
var rider_node: Node3D
var helmet_node: Node3D
var grass: MeshInstance3D
var chase_camera: Camera3D
var helmet_camera: Camera3D
var rivals: Array[Node3D] = []
var rival_lane: Array[float] = []
var rival_pace: Array[float] = []

# --- UI ---
var speed_label: Label
var lap_label: Label
var time_label: Label
var message_label: Label
var pause_label: Label
var pad_rects: Dictionary = {}       # aksi -> Rect2 (koordinat 0..1 layar)
var pad_panels: Dictionary = {}      # aksi -> Panel
var pad_pressed: Dictionary = {}     # aksi -> bool (cache tampilan)
var touch_actions: Dictionary = {}   # index jari -> aksi yang ditahan
var pad_style_normal: StyleBoxFlat
var pad_style_pressed: StyleBoxFlat

var _material_cache: Dictionary = {}

const HOLD_ACTIONS: Array = ["left", "right", "brake", "gas"]

func _ready() -> void:
    randomize()
    _build_world()
    _build_track()
    _build_player()
    _build_rivals()
    _build_cameras()
    _build_ui()
    _set_camera_mode(0)
    _reset_race()

# ---------------------------------------------------------------------------
# Geometri sirkuit (periodik terhadap TRACK_PERIOD)
# ---------------------------------------------------------------------------

func _track_center(z: float) -> float:
    return TRACK_AMPLITUDE * sin(z * TRACK_K)

func _track_slope(z: float) -> float:
    return TRACK_AMPLITUDE * TRACK_K * cos(z * TRACK_K)

# Transform di titik z pada jalur, bergeser "lateral" tegak lurus arah jalan.
func _track_transform(z: float, lateral: float, y: float) -> Transform3D:
    var yaw := atan(_track_slope(z))
    var normal := Vector3(cos(yaw), 0.0, -sin(yaw))
    var origin := Vector3(_track_center(z), y, z) + normal * lateral
    return Transform3D(Basis(Vector3.UP, yaw), origin)

# ---------------------------------------------------------------------------
# Pembuat mesh dasar (semua WAJIB menerima parent)
# ---------------------------------------------------------------------------

func _get_material(color: Color, metallic: float = 0.0,
        roughness: float = 0.85) -> StandardMaterial3D:
    var key := "%s|%.2f|%.2f" % [color.to_html(), metallic, roughness]
    if _material_cache.has(key):
        return _material_cache[key]
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.metallic = metallic
    material.roughness = roughness
    _material_cache[key] = material
    return material

func _add_box(parent: Node3D, node_name: String, pos: Vector3, box_size: Vector3,
        color: Color) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = node_name
    var mesh := BoxMesh.new()
    mesh.size = box_size
    item.mesh = mesh
    item.position = pos
    item.material_override = _get_material(color)
    parent.add_child(item)
    return item

func _add_cylinder(parent: Node3D, pos: Vector3, radius: float, height: float,
        color: Color, axis: int = AXIS_Y) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = 16    # default 64 terlalu berat untuk HP
    mesh.rings = 1
    item.mesh = mesh
    item.position = pos
    if axis == AXIS_X:
        item.rotation_degrees.z = 90.0
    elif axis == AXIS_Z:
        item.rotation_degrees.x = 90.0
    item.material_override = _get_material(color, 0.15, 0.6)
    parent.add_child(item)
    return item

func _add_sphere(parent: Node3D, pos: Vector3, diameter: float,
        color: Color, metallic: float = 0.0) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = diameter * 0.5
    mesh.height = diameter
    mesh.radial_segments = 12
    mesh.rings = 6
    item.mesh = mesh
    item.position = pos
    item.material_override = _get_material(color, metallic, 0.42)
    parent.add_child(item)
    return item

func _add_track_batch(node_name: String, box_size: Vector3, color: Color,
        transforms: Array) -> void:
    var box := BoxMesh.new()
    box.size = box_size
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    multi.mesh = box
    multi.instance_count = transforms.size()
    for i in range(transforms.size()):
        var t: Transform3D = transforms[i]
        multi.set_instance_transform(i, t)
    var batch := MultiMeshInstance3D.new()
    batch.name = node_name
    batch.multimesh = multi
    batch.material_override = _get_material(color, 0.0, 0.88)
    add_child(batch)

# ---------------------------------------------------------------------------
# Dunia & sirkuit
# ---------------------------------------------------------------------------

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color(0.42, 0.68, 0.86, 1.0)
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.72, 0.78, 0.86)
    environment.ambient_light_energy = 0.8
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    # Kabut ringan menyamarkan ujung jalan dan munculnya rival di kejauhan.
    environment.fog_enabled = true
    environment.fog_light_color = Color(0.42, 0.68, 0.86)
    environment.fog_density = 0.005
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48.0, -25.0, 0.0)
    sun.light_energy = 1.2
    sun.shadow_enabled = false
    add_child(sun)

    # Rumput sangat lebar dan mengikuti pemain (lihat _update_race).
    grass = _add_box(self, "Grass", Vector3(0.0, -0.6, -100.0),
        Vector3(1600.0, 1.0, 1600.0), Color(0.12, 0.34, 0.16))

func _build_track() -> void:
    var span := LAP_LENGTH + VIEW_DISTANCE + BEHIND_DISTANCE + 20.0
    var road: Array = []
    var kerb_red: Array = []
    var kerb_white: Array = []
    var lines: Array = []
    var barriers: Array = []

    for i in range(int(ceil(span / SEGMENT_LENGTH))):
        var z := BEHIND_DISTANCE - (i + 0.5) * SEGMENT_LENGTH
        road.append(_track_transform(z, 0.0, -0.04))

    for i in range(int(ceil(span / KERB_STEP))):
        var z := BEHIND_DISTANCE - (i + 0.5) * KERB_STEP
        var target: Array = kerb_red if i % 2 == 0 else kerb_white
        target.append(_track_transform(z, -9.4, 0.02))
        target.append(_track_transform(z, 9.4, 0.02))

    for i in range(int(ceil(span / LINE_STEP))):
        var z := BEHIND_DISTANCE - (i + 0.5) * LINE_STEP
        lines.append(_track_transform(z, 0.0, 0.035))

    for i in range(int(ceil(span / BARRIER_STEP))):
        var z := BEHIND_DISTANCE - (i + 0.5) * BARRIER_STEP
        barriers.append(_track_transform(z, -11.2, 0.7))
        barriers.append(_track_transform(z, 11.2, 0.7))

    _add_track_batch("Road", Vector3(TRACK_WIDTH, 0.12, SEGMENT_LENGTH + 0.5),
        Color(0.12, 0.13, 0.15), road)
    _add_track_batch("KerbRed", Vector3(0.8, 0.18, KERB_STEP + 0.1),
        Color(0.88, 0.12, 0.10), kerb_red)
    _add_track_batch("KerbWhite", Vector3(0.8, 0.18, KERB_STEP + 0.1),
        Color(0.92, 0.92, 0.92), kerb_white)
    _add_track_batch("CenterLine", Vector3(0.18, 0.025, LINE_STEP * 0.5),
        Color(0.92, 0.92, 0.86), lines)
    _add_track_batch("Barrier", Vector3(0.45, 1.4, BARRIER_STEP - 1.5),
        Color(0.72, 0.74, 0.76), barriers)

    # Garis start/finish. Posisi z = 0 dan z = -LAP_LENGTH sama persis setelah wrap.
    _add_gantry(0.0)
    _add_gantry(-LAP_LENGTH)

func _add_gantry(z: float) -> void:
    var line := _add_box(self, "FinishLine", Vector3.ZERO,
        Vector3(TRACK_WIDTH, 0.03, 1.4), Color(0.95, 0.95, 0.95))
    line.transform = _track_transform(z, 0.0, 0.04)
    var post_color := Color(0.16, 0.17, 0.2)
    var post_l := _add_box(self, "GantryPostL", Vector3.ZERO,
        Vector3(0.6, 7.0, 0.6), post_color)
    post_l.transform = _track_transform(z, -10.4, 3.5)
    var post_r := _add_box(self, "GantryPostR", Vector3.ZERO,
        Vector3(0.6, 7.0, 0.6), post_color)
    post_r.transform = _track_transform(z, 10.4, 3.5)
    var beam := _add_box(self, "GantryBeam", Vector3.ZERO,
        Vector3(21.4, 0.9, 0.9), Color(0.85, 0.10, 0.08))
    beam.transform = _track_transform(z, 0.0, 7.2)

# ---------------------------------------------------------------------------
# Motor (SEMUA bagian menjadi anak dari "lean" -> ikut bergerak bersama)
# ---------------------------------------------------------------------------

func _make_wheel(parent: Node3D, pos: Vector3, radius: float, width: float) -> Node3D:
    var pivot := Node3D.new()
    pivot.position = pos
    parent.add_child(pivot)
    _add_cylinder(pivot, Vector3.ZERO, radius, width, Color(0.025, 0.025, 0.03), AXIS_X)
    _add_cylinder(pivot, Vector3.ZERO, radius * 0.55, width + 0.02,
        Color(0.62, 0.64, 0.68), AXIS_X)
    # Jari-jari penanda agar putaran roda terlihat.
    _add_box(pivot, "Spoke", Vector3.ZERO,
        Vector3(width + 0.04, radius * 1.3, 0.05), Color(0.22, 0.23, 0.26))
    return pivot

func _build_bike_model(lean: Node3D, body_color: Color) -> void:
    front_wheel = _make_wheel(lean, Vector3(0.0, WHEEL_Y, -0.8), WHEEL_RADIUS, 0.18)
    rear_wheel = _make_wheel(lean, Vector3(0.0, WHEEL_Y, 0.8), WHEEL_RADIUS, 0.18)

    var fairing := _add_box(lean, "Fairing", Vector3(0.0, 0.98, 0.0),
        Vector3(0.72, 0.55, 1.35), body_color)
    fairing.rotation_degrees.x = -8.0
    _add_box(lean, "Seat", Vector3(0.0, 1.30, 0.35),
        Vector3(0.48, 0.18, 0.65), Color(0.06, 0.06, 0.07))
    _add_box(lean, "Tank", Vector3(0.0, 1.38, -0.18),
        Vector3(0.58, 0.35, 0.55), body_color)
    rider_node = _add_box(lean, "Rider", Vector3(0.0, 1.66, 0.24),
        Vector3(0.42, 0.55, 0.48), Color(0.035, 0.045, 0.07))
    helmet_node = _add_box(lean, "Helmet", Vector3(0.0, 2.12, -0.03),
        Vector3(0.42, 0.42, 0.42), Color(0.88, 0.88, 0.92))
    _add_box(lean, "Windshield", Vector3(0.0, 1.62, -0.50),
        Vector3(0.48, 0.38, 0.12), Color(0.15, 0.28, 0.38))

    # Fork: bawah tepat di poros roda depan, atas miring ke belakang (rake).
    var fork_l := _add_cylinder(lean, Vector3(-0.20, 0.833, -0.676), 0.055, 0.90,
        Color(0.72, 0.74, 0.78))
    fork_l.rotation_degrees.x = 16.0
    var fork_r := _add_cylinder(lean, Vector3(0.20, 0.833, -0.676), 0.055, 0.90,
        Color(0.72, 0.74, 0.78))
    fork_r.rotation_degrees.x = 16.0

    _add_cylinder(lean, Vector3(0.39, 0.82, 0.36), 0.09, 0.85,
        Color(0.30, 0.32, 0.35), AXIS_Z)
    _add_box(lean, "FrontLight", Vector3(0.0, 1.18, -0.70),
        Vector3(0.30, 0.16, 0.08), Color(1.0, 0.92, 0.66))
    _add_sphere(lean, Vector3(-0.31, 1.66, -0.50), 0.12, Color(0.10, 0.10, 0.12), 0.5)
    _add_sphere(lean, Vector3(0.31, 1.66, -0.50), 0.12, Color(0.10, 0.10, 0.12), 0.5)
    _add_box(lean, "LeftFairing", Vector3(-0.37, 0.98, -0.05),
        Vector3(0.12, 0.40, 0.70), body_color)
    _add_box(lean, "RightFairing", Vector3(0.37, 0.98, -0.05),
        Vector3(0.12, 0.40, 0.70), body_color)

func _make_simple_bike(color: Color) -> Node3D:
    # Model lawan: sedikit node agar ringan. Semua bagian anak dari "bike".
    var bike := Node3D.new()
    add_child(bike)
    var wheel_y := 0.36
    _add_cylinder(bike, Vector3(0.0, wheel_y, -0.72), 0.34, 0.16,
        Color(0.025, 0.025, 0.03), AXIS_X)
    _add_cylinder(bike, Vector3(0.0, wheel_y, 0.72), 0.34, 0.16,
        Color(0.025, 0.025, 0.03), AXIS_X)
    _add_box(bike, "RivalBody", Vector3(0.0, 1.02, 0.0),
        Vector3(0.68, 0.52, 1.25), color)
    _add_box(bike, "RivalRider", Vector3(0.0, 1.55, 0.18),
        Vector3(0.42, 0.58, 0.48), Color(0.035, 0.045, 0.07))
    _add_sphere(bike, Vector3(0.0, 1.98, -0.02), 0.40, Color(0.88, 0.88, 0.92))
    return bike

func _build_player() -> void:
    player_bike = Node3D.new()
    player_bike.name = "PlayerBike"
    add_child(player_bike)
    player_lean = Node3D.new()
    player_lean.name = "Lean"
    player_bike.add_child(player_lean)
    _build_bike_model(player_lean, Color(0.82, 0.035, 0.025))

func _build_rivals() -> void:
    var colors: Array[Color] = [Color(0.05, 0.22, 0.82), Color(0.95, 0.66, 0.02)]
    for i in range(colors.size()):
        var rival := _make_simple_bike(colors[i])
        rivals.append(rival)
        rival_lane.append(0.0)
        rival_pace.append(0.75 + i * 0.07)

func _build_cameras() -> void:
    # Kamera belakang menempel di root motor (tidak ikut miring/lean).
    chase_camera = Camera3D.new()
    chase_camera.position = Vector3(0.0, 4.2, 9.0)
    chase_camera.rotation_degrees = Vector3(-18.0, 0.0, 0.0)
    chase_camera.fov = 70.0
    chase_camera.near = 0.1
    chase_camera.far = 360.0
    player_bike.add_child(chase_camera)

    # Kamera helm menempel di "lean" agar ikut miring seperti pembalap.
    helmet_camera = Camera3D.new()
    helmet_camera.position = Vector3(0.0, 2.02, -0.20)
    helmet_camera.rotation_degrees = Vector3(-2.0, 0.0, 0.0)
    helmet_camera.fov = 86.0
    helmet_camera.near = 0.1
    helmet_camera.far = 360.0
    player_lean.add_child(helmet_camera)

# ---------------------------------------------------------------------------
# UI + kontrol sentuh multi-touch
# ---------------------------------------------------------------------------

func _make_label(parent: Control, pos: Vector2, font_size: int, color: Color) -> Label:
    var label := Label.new()
    label.position = pos
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.add_theme_color_override("font_outline_color", Color.BLACK)
    label.add_theme_constant_override("outline_size", 6)
    parent.add_child(label)
    return label

func _pad_style(bg: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.set_corner_radius_all(16)
    style.set_border_width_all(3)
    style.border_color = Color(1.0, 1.0, 1.0, 0.55)
    return style

func _make_pad(parent: Control, action: String, text: String, pos: Vector2,
        pad_size: Vector2) -> Label:
    var panel := Panel.new()
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.anchor_left = pos.x
    panel.anchor_top = pos.y
    panel.anchor_right = pos.x + pad_size.x
    panel.anchor_bottom = pos.y + pad_size.y
    panel.offset_left = 0.0
    panel.offset_top = 0.0
    panel.offset_right = 0.0
    panel.offset_bottom = 0.0
    panel.add_theme_stylebox_override("panel", pad_style_normal)
    parent.add_child(panel)

    var label := Label.new()
    label.text = text
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 22)
    label.add_theme_color_override("font_color", Color.WHITE)
    panel.add_child(label)
    label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    pad_rects[action] = Rect2(pos, pad_size)
    pad_panels[action] = panel
    pad_pressed[action] = false
    return label

func _build_ui() -> void:
    pad_style_normal = _pad_style(Color(0.0, 0.0, 0.0, 0.38))
    pad_style_pressed = _pad_style(Color(1.0, 1.0, 1.0, 0.38))

    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    speed_label = _make_label(root, Vector2(28, 16), 34, Color.WHITE)
    lap_label = _make_label(root, Vector2(28, 62), 22, Color.YELLOW)
    time_label = _make_label(root, Vector2(28, 94), 20, Color(0.85, 0.95, 1.0))

    message_label = _make_label(root, Vector2.ZERO, 24, Color.WHITE)
    message_label.anchor_left = 0.5
    message_label.anchor_right = 0.5
    message_label.offset_left = -330.0
    message_label.offset_right = 330.0
    message_label.offset_top = 22.0
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

    _make_pad(root, "camera", "KAMERA", Vector2(0.82, 0.04), Vector2(0.15, 0.09))
    pause_label = _make_pad(root, "pause", "JEDA", Vector2(0.82, 0.15), Vector2(0.15, 0.09))
    _make_pad(root, "left", "KIRI", Vector2(0.03, 0.78), Vector2(0.14, 0.17))
    _make_pad(root, "right", "KANAN", Vector2(0.19, 0.78), Vector2(0.14, 0.17))
    _make_pad(root, "brake", "REM", Vector2(0.67, 0.78), Vector2(0.14, 0.17))
    _make_pad(root, "gas", "GAS", Vector2(0.83, 0.78), Vector2(0.14, 0.17))

# Tombol bawaan Godot hanya mendukung 1 jari sekaligus. Untuk balap kita butuh
# GAS + KIRI/KANAN bersamaan, jadi sentuhan diproses sendiri per-jari.
func _action_at(pos: Vector2) -> String:
    var vp_size := get_viewport().get_visible_rect().size
    if vp_size.x <= 0.0 or vp_size.y <= 0.0:
        return ""
    var n := Vector2(pos.x / vp_size.x, pos.y / vp_size.y)
    for action in pad_rects:
        var rect: Rect2 = pad_rects[action]
        if rect.grow(0.012).has_point(n):
            return str(action)
    return ""

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var touch := event as InputEventScreenTouch
        if touch.pressed and not touch.canceled:
            _touch_down(touch.index, touch.position)
        else:
            touch_actions.erase(touch.index)
    elif event is InputEventScreenDrag:
        var drag := event as InputEventScreenDrag
        _touch_move(drag.index, drag.position)

func _touch_down(index: int, pos: Vector2) -> void:
    var action := _action_at(pos)
    if action == "":
        return
    match action:
        "camera":
            _toggle_camera()
        "pause":
            _on_pause_pressed()
        _:
            touch_actions[index] = action

func _touch_move(index: int, pos: Vector2) -> void:
    if not touch_actions.has(index):
        return
    var action := _action_at(pos)
    if HOLD_ACTIONS.has(action):
        touch_actions[index] = action   # geser jari KIRI -> KANAN langsung berpindah
    else:
        touch_actions.erase(index)

func _poll_inputs() -> void:
    var held: Array = touch_actions.values()
    throttle = (held.has("gas") or Input.is_key_pressed(KEY_SPACE)
        or Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W))
    braking = (held.has("brake") or Input.is_key_pressed(KEY_DOWN)
        or Input.is_key_pressed(KEY_S))
    steer_left = (held.has("left") or Input.is_key_pressed(KEY_LEFT)
        or Input.is_key_pressed(KEY_A))
    steer_right = (held.has("right") or Input.is_key_pressed(KEY_RIGHT)
        or Input.is_key_pressed(KEY_D))

func _refresh_pad_visuals() -> void:
    var active := {"gas": throttle, "brake": braking,
        "left": steer_left, "right": steer_right}
    for action in HOLD_ACTIONS:
        var pressed: bool = active[action]
        if pressed != pad_pressed[action]:
            pad_pressed[action] = pressed
            var panel: Panel = pad_panels[action]
            panel.add_theme_stylebox_override("panel",
                pad_style_pressed if pressed else pad_style_normal)

func _unhandled_key_input(event: InputEvent) -> void:
    var key := event as InputEventKey
    if key == null or not key.pressed or key.echo:
        return
    match key.keycode:
        KEY_C:
            _toggle_camera()
        KEY_P, KEY_ESCAPE:
            if state != State.FINISHED:
                _on_pause_pressed()
        KEY_R:
            _reset_race()

# Saat aplikasi ke background, tombol "lepas" tidak pernah terkirim -> gas
# bisa tersangkut. Bersihkan input dan jeda otomatis.
func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
        touch_actions.clear()
        if state == State.RACING:
            _set_paused(true)

# ---------------------------------------------------------------------------
# Kamera, pesan, jeda, reset
# ---------------------------------------------------------------------------

func _toggle_camera() -> void:
    _set_camera_mode(1 - camera_mode)

func _set_camera_mode(mode: int) -> void:
    camera_mode = mode
    if mode == 0:
        chase_camera.make_current()
    else:
        helmet_camera.make_current()
    # Pada kamera helm, sembunyikan helm & pembalap supaya tidak menutupi layar.
    helmet_node.visible = mode == 0
    rider_node.visible = mode == 0
    _show_message("KAMERA: " + ("BELAKANG" if mode == 0 else "HELM"), 1.5)

func _show_message(text: String, duration: float = 2.0) -> void:
    message_label.text = text
    message_time = duration

func _update_message(dt: float) -> void:
    if message_time > 0.0:
        message_time -= dt
        if message_time <= 0.0:
            message_time = 0.0
            message_label.text = ""

func _update_pause_text() -> void:
    match state:
        State.RACING:
            pause_label.text = "JEDA"
        State.PAUSED:
            pause_label.text = "LANJUT"
        State.FINISHED:
            pause_label.text = "ULANG"

func _on_pause_pressed() -> void:
    match state:
        State.RACING:
            _set_paused(true)
        State.PAUSED:
            _set_paused(false)
        State.FINISHED:
            _reset_race()

func _set_paused(value: bool) -> void:
    if state == State.FINISHED:
        return
    state = State.PAUSED if value else State.RACING
    _show_message("DIJEDA" if value else "", 0.0)
    _update_pause_text()

func _reset_race() -> void:
    state = State.RACING
    speed = 0.0
    player_x = 0.0
    lateral_x = 0.0
    lean_angle = 0.0
    wheel_spin = 0.0
    lap = 1
    score_f = 0.0
    score = 0
    race_time = 0.0
    lap_start_time = 0.0
    best_lap = -1.0
    timing_started = false
    player_yaw = atan(_track_slope(0.0))
    player_bike.position = Vector3(_track_center(0.0), 0.0, 0.0)
    player_bike.rotation.y = player_yaw
    player_lean.rotation.z = 0.0
    var lanes: Array[float] = [-4.0, 4.0]
    for i in range(rivals.size()):
        var rz := -32.0 - i * 36.0
        rival_lane[i] = lanes[i]
        rivals[i].position = Vector3(_track_center(rz) + lanes[i], 0.0, rz)
        rivals[i].rotation.y = atan(_track_slope(rz))
    _update_pause_text()
    _show_message("TAHAN GAS UNTUK MULAI", 3.0)

# ---------------------------------------------------------------------------
# Loop utama (pakai _process: tidak ada fisika, jadi tidak ada stutter akibat
# physics tick 30 Hz yang tidak sinkron dengan render 30 FPS)
# ---------------------------------------------------------------------------

func _process(delta: float) -> void:
    var dt := minf(delta, 0.1)
    _poll_inputs()
    _refresh_pad_visuals()
    _update_message(dt)
    if state != State.PAUSED:
        _update_race(dt)
    _update_hud()

func _update_race(dt: float) -> void:
    var racing := state == State.RACING

    if racing and throttle:
        speed += ACCELERATION * dt
    else:
        speed -= DRAG * dt
    if racing and braking:
        speed -= BRAKE_POWER * dt
    elif not racing:
        speed -= BRAKE_POWER * 0.5 * dt   # setelah finish motor berhenti sendiri
    speed = clampf(speed, 0.0, MAX_SPEED)

    var steer := 0.0
    if racing:
        if steer_left:
            steer -= 1.0
        if steer_right:
            steer += 1.0
    # Motor diam tidak boleh bergeser menyamping.
    var grip := clampf(speed / 15.0, 0.0, 1.0)

    player_x += steer * (3.0 + speed * 0.025) * grip * dt
    player_x = clampf(player_x, -MAX_STEER_OFFSET, MAX_STEER_OFFSET)
    lateral_x = lerpf(lateral_x, player_x, 1.0 - exp(-10.0 * dt))

    var world_speed := speed * WORLD_SPEED
    var z := player_bike.position.z - world_speed * dt
    player_bike.position.z = z
    player_bike.position.x = _track_center(z) + lateral_x

    var target_yaw := atan(_track_slope(z)) - steer * 0.08 * grip
    player_yaw = lerp_angle(player_yaw, target_yaw, 1.0 - exp(-6.0 * dt))
    player_bike.rotation.y = player_yaw
    lean_angle = lerpf(lean_angle, -steer * 0.22 * grip, 1.0 - exp(-6.0 * dt))
    player_lean.rotation.z = lean_angle

    wheel_spin = fmod(wheel_spin - minf(world_speed / WHEEL_RADIUS, 25.0) * dt, TAU)
    front_wheel.rotation.x = wheel_spin
    rear_wheel.rotation.x = wheel_spin

    _update_rivals(dt)

    if racing:
        if speed > 0.5:
            timing_started = true
        if timing_started:
            race_time += dt
        score_f += speed * dt * 0.08   # akumulasi float (int() per frame selalu 0)
        score = int(score_f)

    # Loop lap: dunia periodik, jadi geser tepat satu LAP_LENGTH tanpa terlihat.
    if player_bike.position.z <= -LAP_LENGTH:
        player_bike.position.z += LAP_LENGTH
        for rival in rivals:
            rival.position.z += LAP_LENGTH
        if racing:
            _on_lap_completed()

    grass.position.z = player_bike.position.z - 100.0

    var ratio := speed / MAX_SPEED
    chase_camera.fov = lerpf(70.0, 82.0, ratio)
    helmet_camera.fov = lerpf(86.0, 98.0, ratio)

func _update_rivals(dt: float) -> void:
    var player_z := player_bike.position.z
    for i in range(rivals.size()):
        var rival := rivals[i]
        rival.position.z -= rival_pace[i] * speed * WORLD_SPEED * dt
        if rival.position.z > player_z + 14.0:
            rival.position.z = player_z - randf_range(70.0, 130.0)
            rival_lane[i] = randf_range(-5.5, 5.5)
        rival.position.x = _track_center(rival.position.z) + rival_lane[i]
        rival.rotation.y = atan(_track_slope(rival.position.z))

        if (absf(rival.position.z - player_z) < 2.2
                and absf(rival.position.x - player_bike.position.x) < 1.25):
            speed = maxf(0.0, speed - 90.0 * dt)
            var push := signf(player_bike.position.x - rival.position.x)
            if push == 0.0:
                push = 1.0
            player_x = clampf(player_x + push * 5.0 * dt,
                -MAX_STEER_OFFSET, MAX_STEER_OFFSET)
            _show_message("KONTAK! JAGA JARAK", 1.0)

func _on_lap_completed() -> void:
    var lap_time := race_time - lap_start_time
    lap_start_time = race_time
    if best_lap < 0.0 or lap_time < best_lap:
        best_lap = lap_time
    if lap >= TOTAL_LAPS:
        state = State.FINISHED
        _update_pause_text()
        _show_message("SELESAI!  SKOR %d  |  WAKTU %s" % [score, _format_time(race_time)], 0.0)
    else:
        lap += 1
        _show_message("LAP %d SELESAI  |  %s" % [lap - 1, _format_time(lap_time)], 2.5)

func _format_time(t: float) -> String:
    var minutes := int(t / 60.0)
    var seconds := t - minutes * 60.0
    var pad := "0" if seconds < 10.0 else ""
    return "%02d:%s%.1f" % [minutes, pad, seconds]

func _update_hud() -> void:
    speed_label.text = "%d km/j" % int(speed)
    lap_label.text = "LAP %d / %d   |   SKOR %d" % [lap, TOTAL_LAPS, score]
    var best_text := "--" if best_lap < 0.0 else _format_time(best_lap)
    time_label.text = "WAKTU %s   |   TERBAIK %s" % [_format_time(race_time), best_text]
