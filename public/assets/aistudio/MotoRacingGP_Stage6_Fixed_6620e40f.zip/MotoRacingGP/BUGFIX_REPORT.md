# Laporan perbaikan - Moto Racing GP Stage 6

Catatan: Godot tidak tersedia di lingkungan audit, jadi analisis dilakukan statis
(baca kode baris per baris). Mohon uji di perangkat dan kirim Debugger > Errors bila ada sisa error.

## A. Bug yang kamu laporkan
| # | Gejala | Akar masalah | Perbaikan |
|---|--------|--------------|-----------|
| 1 | Error saat mulai | `var lane_x := [-4.0, 4.0][i]` : tipe tidak bisa di-infer dari array tanpa tipe -> parse error, script tidak termuat | Lane memakai `Array[float]` bertipe, tanpa `:=` dari Variant. Rival kini pakai array paralel bertipe, bukan `set_meta/get_meta` |
| 2 | Body & roda terpisah saat jalan | `_add_box()` selalu `add_child` ke node Main, bukan ke motor. Hanya silinder (roda/fork/knalpot) yang ikut `parent`. Bodi, jok, tangki, pembalap, helm, lampu tertinggal di titik awal. Rival sama | Semua pembuat mesh sekarang WAJIB menerima `parent`; seluruh bagian jadi anak node `Lean` -> `PlayerBike` |

## B. Bug lain yang ditemukan
1. **Roda salah orientasi**: silinder diputar di sumbu X sehingga roda menghadap depan seperti koin. Sekarang as roda di sumbu X (sisi motor).
2. **Roda melayang** 0.08 unit di atas aspal (pusat y=0.48 untuk radius 0.38). Sekarang y=0.40, ban tepat menyentuh jalan.
3. **Fork miring ke arah salah** dan ujung bawahnya tidak di poros roda. Dikoreksi (rake ke belakang, ujung bawah di as roda).
4. **Bagian melayang**: pembalap 0.055 di atas jok, spion mengambang, kaca depan tidak menyentuh tangki. Diposisikan ulang agar menempel.
5. **Skor selalu 0**: `int(speed*delta*0.08)` < 1 per frame, selalu terpotong jadi 0. Sekarang akumulasi float.
6. **Tombol UI hanya 1 jari**: `Button` Godot tidak multi-touch, jadi GAS + KIRI/KANAN tidak bisa bersamaan di HP. Diganti penanganan sentuhan per-jari (`InputEventScreenTouch/Drag`), geser jari antar tombol juga bekerja. Mouse-emulation dimatikan, touch-emulation dari mouse dinyalakan agar tetap bisa dites di PC.
7. **Gas/rem tersangkut** saat aplikasi ke background (event "lepas" tidak terkirim). Sekarang input dibersihkan dan game jeda otomatis.
8. **Lompatan di akhir lap**: kurva sinus tidak periodik terhadap `ROAD_LENGTH/2`, sehingga posisi x dan arah motor "loncat" (~9 derajat) saat reset. Sirkuit kini periodik (loop 540 unit = 2 periode), semua jarak segmen habis dibagi sehingga pola garis/kerb/barrier juga mulus.
9. **Jalan habis di kejauhan**: jalan hanya sampai z=-361 padahal kamera melihat 350 dari z=-130. Jalan dibangun sesuai jarak pandang + loop.
10. **Rumput berujung di sisi** (lebar 220) dan tidak ikut pemain. Sekarang 1600 lebar dan mengikuti pemain. Ditambah kabut ringan agar ujung jalan/munculnya rival halus.
11. **Rival menyamping**: tidak mengikuti arah tikungan. Sekarang yaw mengikuti jalan.
12. **Stutter**: gerak di `_physics_process` (30 Hz) sementara render dibatasi 30 FPS -> frame fisika tidak sinkron. Pindah ke `_process` (tidak ada fisika), delta di-clamp, smoothing pakai `1-exp(-k*dt)` (stabil di berapa pun FPS), dan lag posisi lateral terhadap tikungan dihilangkan.
13. **Motor bisa geser menyamping saat diam**: steering sekarang diskalakan oleh kecepatan.
14. **Pesan "KONTAK!" tidak pernah hilang** -> sistem pesan dengan timer.
15. **Akhir balapan rusak**: setelah lap 3 game di-pause lalu lap kembali 1 dan skor tidak reset. Sekarang ada state `RACING/PAUSED/FINISHED`, hasil akhir, dan tombol ULANG.
16. **Kamera helm di dalam helm/pembalap**: helm & pembalap disembunyikan di mode helm. Kamera belakang tidak ikut miring (lean) lagi.
17. **Layar 20:9 (Infinix Note 40 Pro)** kena letterbox hitam: `stretch/aspect="expand"`, orientasi `sensor_landscape`.
18. **Performa**: silinder default 64 segmen -> 16; material dibagi (cache); kerb merah/putih via MultiMesh.
19. Konfigurasi: tambah `import_etc2_astc=true` (dibutuhkan export Android), hapus `physics_ticks_per_second` (tidak ada fisika), komentar "Stage 3" diperbarui.

## C. Tambahan
Roda berputar, motor miring (lean) + sedikit yaw saat belok, FOV naik sesuai kecepatan, garis start/finish + gantry, kerb merah-putih, timer & lap terbaik, rival tidak lagi bisa ditembus tanpa efek (kecepatan turun + terdorong ke samping), HUD dengan outline agar terbaca.

## D. Belum diubah (sengaja)
Kecepatan rival masih proporsional dengan kecepatan pemain (75-82%), jadi hanya berfungsi sebagai "lalu lintas", bukan lawan balap sungguhan. Itu perubahan gameplay, bukan bug.
