MOTO RACING GP - STAGE 6: CURVED CIRCUIT (REVISI ENGINEERING)

Target: Godot 4.3+ (Android Editor juga bisa), GL Compatibility, landscape, 30 FPS.

Cara pakai:
1. Ekstrak ZIP ke folder BARU (jangan timpa folder lama / hapus folder .godot lama).
2. Godot > Import > pilih project.godot.
3. Buka Main.tscn lalu Play.
4. Tahan GAS, tekan KIRI/KANAN bersamaan (multi-touch). Selesaikan 3 lap.

Kontrol sentuh : GAS, REM, KIRI, KANAN, KAMERA, JEDA (JEDA berubah jadi ULANG saat selesai)
Kontrol keyboard (tes di PC): Spasi/W gas, S/Bawah rem, A/D atau panah kiri-kanan,
                              C kamera, P jeda, R ulang

Ringkasan perbaikan ada di BUGFIX_REPORT.md.
Ini prototipe sirkuit S ringan, bukan sirkuit MotoGP resmi.
Jika masih ada error, kirim screenshot Debugger > Errors.
